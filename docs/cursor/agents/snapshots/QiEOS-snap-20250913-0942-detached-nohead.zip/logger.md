# Agent: Logger — Session Append

ROLE: Logger

TARGET
- Append to: `docs/DEV_LOG.md`
- Template: `docs/cursor/agents/templates/session-entry.md`

TASKS
1) If `docs/DEV_LOG.md` is missing, create it with a project header and today’s date.
2) Fill the Session Entry template with:
   - Date, Start–End (local time), Branch, PR link (if any)
   - Goal, What Changed, Why, How, How to Test
   - Diffs applied (paths), Decisions, Rollback, Open Questions
   - Next 1–2 steps
   - Optional Snapshot name/path
3) Append entry at bottom of `docs/DEV_LOG.md` (never overwrite).
4) Stage & commit:  
   ```powershell
   git add docs/DEV_LOG.md
   git commit -m "docs: devlog update ($(Get-Date -Format 'yyyy-MM-dd HH:mm'))"
If a PR was created, include the link in the same entry.

RULES

Print the markdown diff; WAIT for explicit approval.

Respect locks; abort if docs/DEV_LOG.md is locked.

If the session caused material changes to architecture/schema/workflow, also call a diff for docs/QiEOS.md.